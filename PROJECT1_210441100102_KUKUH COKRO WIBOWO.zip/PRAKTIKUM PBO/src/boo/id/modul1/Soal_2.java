package boo.id.modul1;

class manusia{
    String Nama, Alamat;
    int Umur;

    void berjalan(String jalannya){
        System.out.println(jalannya);
    }
    void berlari(String larinya){
        System.out.println(larinya);
    }
}
public class Soal_2 {
    public static void main(String[] args) {
        System.out.println("========== OBJEK 1 ==========");
        manusia kuhh = new manusia();
        kuhh.Nama = "Kukuh Cokro";
        System.out.println("Nama   = " + kuhh.Nama);

        kuhh.Umur = 19;
        System.out.println("Umur   = " + kuhh.Umur);

        kuhh.Alamat = "Kandangan, Kediri";
        System.out.println("Alamat = " + kuhh.Alamat);
        System.out.println("----------------------------------");

        System.out.println("-- Ketika disuruh berjalan, dia akan bilang : ");
        kuhh.berjalan("=> Objek 1 Siap Berjalan");

        System.out.println("-- Ketika disuruh berlari, dia akan bilang : ");
        kuhh.berlari("=> Objek 1 Siap Berlari, sat set wat wet");

        System.out.println("\n\n========== OBJEK 2 ==========");
        manusia juvv = new manusia();

        juvv.Nama = "Andhika Juve";
        System.out.println("Nama   = " + juvv.Nama);

        juvv.Umur = 19;
        System.out.println("Umur   = " + juvv.Umur);

        juvv.Alamat = "Pare, Kediri";
        System.out.println("Alamat = " + juvv.Alamat);
        System.out.println("--------------------------------");
        System.out.println("-- Ketika berjalan, suaranya : ");
        juvv.berjalan("=> (ga ada suaranya)");
        System.out.println("-- Ketika berlari, suaranya : ");
        juvv.berlari("=> wusss");
    }
}
