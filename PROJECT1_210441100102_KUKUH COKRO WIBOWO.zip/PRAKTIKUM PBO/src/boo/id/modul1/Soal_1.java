package boo.id.modul1;

class human {
    String Nama, NIM, Jurusan, Prodi, Alamat;
}

public class Soal_1 {
    public static void main (String[] args){
        System.out.println("====== DATA MAHASISWA ======\n");
        human mahasiswa = new human();

        mahasiswa.Nama = "Kukuh Cokro Wibowo";
        System.out.println("Nama          = " + mahasiswa.Nama);

        mahasiswa.NIM = "210441100102";
        System.out.println("NIM           = " + mahasiswa.NIM);

        mahasiswa.Jurusan = "Teknik Informatika";
        mahasiswa.Prodi = "Sistem Informasi";
        System.out.println("Jurusan/Prodi = " + mahasiswa.Jurusan + " / " + mahasiswa.Prodi);

        mahasiswa.Alamat = "Kediri";
        System.out.println("Alamat        = " + mahasiswa.Alamat);
    }

}
