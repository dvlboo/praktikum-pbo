package boo.id.modul1;

import java.util.Scanner;

public class Soal_3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        human mhs = new human();

        System.out.println("===== Please Input Your Data =====\n");

        System.out.println("Name :");
        mhs.Nama = input.nextLine();
        System.out.println("NIM :");
        mhs.NIM = input.nextLine();
        System.out.println("Major :");
        mhs.Jurusan = input.nextLine();
        System.out.println("Study Program :");
        mhs.Prodi = input.nextLine();
        System.out.println("Address :");
        mhs.Alamat = input.nextLine();

        System.out.println("\n===== DATA MAHASISWA =====\n");
        System.out.println("Nama            = " + mhs.Nama);
        System.out.println("NIM             = " + mhs.NIM);
        System.out.println("Jurusan / Prodi = " + mhs.Jurusan + " / " + mhs.Prodi);
        System.out.println("Alamat          = " + mhs.Alamat);

    }

}
