package modul3.boo;

import java.util.Scanner;
public class childData extends parentData{
    static String Major, Address;

    public static String getAddress(){
        return Address;
    }
    public static void setAddress(String address) {
        Address = address;
    }

    public static String getMajor() {
        Scanner input = new Scanner(System.in);
        switch (Major) {
            case "61":
                System.out.println("\n=== DATA MAHASISWA " + getUniversity() + " ===");
                System.out.println("NIM     : " + getNIM());
                System.out.println("Nama    : " + getName());
                System.out.println("Alamat  : " + getAddress());
                System.out.println("Jurusan : Matematika");
                break;
            case "62":
                System.out.println("\n=== DATA MAHASISWA " + getUniversity() + " ===");
                System.out.println("NIM     : " + getNIM());
                System.out.println("Nama    : " + getName());
                System.out.println("Alamat  : " + getAddress());
                System.out.println("Jurusan : Biologi");
                break;
            case "63":
                System.out.println("\n=== DATA MAHASISWA " + getUniversity() + " ===");
                System.out.println("NIM     : " + getNIM());
                System.out.println("Nama    : " + getName());
                System.out.println("Alamat  : " + getAddress());
                System.out.println("Jurusan : Kimia");
                break;
            case "64":
                System.out.println("\n=== DATA MAHASISWA " + getUniversity() + " ===");
                System.out.println("NIM     : " + getNIM());
                System.out.println("Nama    : " + getName());
                System.out.println("Alamat  : " + getAddress());
                System.out.println("Jurusan : Fisika");
                break;
            case "65":
                System.out.println("\n=== DATA MAHASISWA " + getUniversity() + " ===");
                System.out.println("NIM     : " + getNIM());
                System.out.println("Nama    : " + getName());
                System.out.println("Alamat  : " + getAddress());
                System.out.println("Jurusan : Teknik Informatika");
                break;
            case "66":
                System.out.println("\n=== DATA MAHASISWA " + getUniversity() + " ===");
                System.out.println("NIM     : " + getNIM());
                System.out.println("Nama    : " + getName());
                System.out.println("Alamat  : " + getAddress());
                System.out.println("Jurusan : Sistem Informasi");
                break;
            default:
                System.out.println("Kode Jurusan Tidak Ada");
                System.out.print("Input Kode Jurusan Yang Tersedia = "); Major = input.nextLine();
                getMajor();
        }
        return Major;
    }
    public static void setMajor(String major) {
        Major = major;
    }
}
