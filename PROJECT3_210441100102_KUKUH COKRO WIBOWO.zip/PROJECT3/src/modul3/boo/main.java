package modul3.boo;

import java.util.Scanner;
public class main extends childData{
    public static void main(String[] args){
        String repeat = "Y";
        while(repeat.equals("Y")){
            Scanner input = new Scanner(System.in);
            System.out.println("===== INPUT DATA MAHASISWA =====");
            System.out.print("Instansi   = "); University = input.nextLine();
            System.out.print("NIM        = "); NIM = input.nextLine();
            System.out.print("Nama       = "); Name = input.nextLine();
            System.out.print("Alamat     = "); Address = input.nextLine();

            System.out.println("| ====== JURUSAN ====== || KODE |");
            System.out.println("| Matematika            || [61] |");
            System.out.println("| Biologi               || [62] |");
            System.out.println("| Kimia                 || [63] |");
            System.out.println("| Fisika                || [64] |");
            System.out.println("| Teknik Informatika    || [65] |");
            System.out.println("| Sistem Informasi      || [66] |");
            System.out.println("| ============================= |");
            System.out.print("Input Kode Jurusan = "); Major = input.nextLine();
            getMajor();

            System.out.println("\nIngin Memasukkan Data Lagi ?");
            System.out.println("1. Yes [Y] or\n2. No [N]");
            System.out.print("=> "); repeat = input.nextLine();
            if (repeat.startsWith("Y")){
                repeat = "Y";
            } else {
                System.out.println("\n===== TERIMAKASIH TELAH MENGGUNAKAN PROGRAM =====");
            }
        }
    }
}
