package modul3.boo;

public class parentData {
    static String Name, NIM, University;

    public static String getName(){
        return Name;
    }
    public static void setName(String name){
        Name = name;
    }
    public static String getNIM(){
        return NIM;
    }
    public static void setNIM(String nim){
        NIM = nim;
    }
    public static String getUniversity(){
        return University;
    }
    public static void setUniversity(String university) {
        University = university;
    }
}
