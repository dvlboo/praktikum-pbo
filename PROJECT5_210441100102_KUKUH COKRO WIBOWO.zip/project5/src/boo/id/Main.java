package boo.id;

final class Main {
    private static void tampilkan(bilanganAbs[] OB, double a, double b) {
        OB[0] = new operasiPenjumlahan();
        OB[1] = new operasiPengurangan();
        OB[2] = new operasiPerkalian();
        OB[3] = new operasiPembagian();

        System.out.println("\nNAMA  : Kukuh Cokro Wibowo");
        System.out.println("NIM   : 210441100102");
        System.out.println("KELAS : PBO A");
        System.out.println("\n\nDiketahui Suatu Bilangan");
        System.out.println("Angka Pertama\t : " + a + "\t|");
        System.out.println("Angka Kedua\t\t : " + b + "\t|\n");

        for (int i = 0; i < OB.length; i++) {
            OB[i].setA(a);
            OB[i].setB(b);
            OB[i].setC();
            OB[i].running();
        }
    }

    public static void main(String[] args) {
        bilanganAbs[] dataOperasi = new bilanganAbs[4];
        tampilkan(dataOperasi, 6.5, 0.5);
    }
}