package boo.id;

public class operasiPerkalian extends bilanganAbs {

    @Override
    protected void setA(double bilA){
        this.a = bilA;
    }
    protected double getA() {
        return a;
    }
    protected void setB(double bilB){
        this.b = bilB;
    }
    protected double getB() {
        return b;
    }
    protected void setC() {
        this.c = a*b;
    }
    protected double getC() {
        return c;
    }
    protected void running() {
        System.out.println("Hasil Perkalian : ");
        System.out.println(getA() + " * " + getB() + " = " + getC() + "\n");
    }
}
