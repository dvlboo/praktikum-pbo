package boo.id;

abstract class bilanganAbs {
    protected double a, b, c;
    protected abstract void setA(double bilA);
    protected abstract double getA();
    protected abstract void setB(double bilB);
    protected abstract double getB();
    protected abstract void setC();
    protected abstract double getC();
    protected abstract void running();
}