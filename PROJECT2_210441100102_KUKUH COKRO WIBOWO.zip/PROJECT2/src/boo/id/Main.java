package boo.id;

import java.util.Scanner;

public class Main{
    public static void main(String[] args) {
        input rental = new input();

        Scanner input = new Scanner(System.in);
        String choosing = "1";

        while (choosing == "1"){
            rental.vcd_shop();


            System.out.println("\nIngin Mengulangi Program ?");
            System.out.print("yes/ya => " );
            choosing = input.nextLine();
            if (choosing.startsWith("y")){
                choosing="1";
                System.out.println("\n===============================");
            }else{
                System.out.println("===== Thank You <3 =====");
            }

        }
    }
}