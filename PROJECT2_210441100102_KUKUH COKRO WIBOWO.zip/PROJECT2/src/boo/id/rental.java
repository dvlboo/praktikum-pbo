package boo.id;

public class rental extends input{
    String vcd_player;
    int stok;

    void Prefix(){
        System.out.println("\n=== Film Yang Terdata ===\n");
    }
    void Title(){
        System.out.println("Judul Film     : "+this.vcd_player);
    }
    void Actor(){
        System.out.println("Aktor Film     : "+this.vcd_player);
    }
    void Director(){
        System.out.println("Sutradara film : "+this.vcd_player);
    }
    void Publisher(){
        System.out.println("Publisher film : "+this.vcd_player);
    }
    void Categori(){
        System.out.println("Kategori film  : "+this.vcd_player);
    }
    void Stock(){
        System.out.println("Stok Film      : "+this.stok);
    }
}
