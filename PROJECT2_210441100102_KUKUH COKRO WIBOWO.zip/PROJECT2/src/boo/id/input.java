package boo.id;

import java.util.Scanner;

class input {
    Scanner in = new Scanner (System.in);
    Scanner in2 = new Scanner (System.in);

    void vcd_shop(){
        System.out.println("\n=== Welcome To My VCD Rentals ===");
        System.out.println("Input All Questions");
        rental title = new rental();
        System.out.print ("Movie Title      => ");
        title.vcd_player = in.nextLine();


        rental actor = new rental();
        System.out.print ("Movie Actor      => ")   ;
        actor.vcd_player = in.nextLine();

        rental director = new rental();
        System.out.print ("Film Director    => ")  ;
        director.vcd_player = in.nextLine();

        rental publisher = new rental();
        System.out.print ("Movie Publisher  => ");
        publisher.vcd_player = in.nextLine();

        System.out.println ("\n=== Categori ===");
        System.out.println ("1. SU (Semua Umur)");
        System.out.println ("2. D  (Dewasa)");
        System.out.println ("3. R  (Remaja)");
        System.out.println ("4. A  (Anak-Anak)");
        System.out.print ("Choose the Categori => ");

        rental kel = new rental();
        String kuh1 = "y";
        byte kuh ;
        do{
            kuh = in2.nextByte();
            if (kuh == 1){
                kel.vcd_player = "SU (Semua Umur)";
                kuh1 = "y";
            }else if (kuh == 2){
                kel.vcd_player = "D (Dewasa)";
                kuh1 = "y";
            }else if (kuh == 3){
                kel.vcd_player = "R (Remaja)";
                kuh1 = "y";
            }else if (kuh == 4){
                kel.vcd_player = "A (Anak-Anak)";
                kuh1 = "y";
            }else{
                System.out.println("Pilihan tidak ada, mohon masukan dengan benar !!! ");
                System.out.print ("Masukkan pilihan : ");
                kuh1 = "t";
            }
        }
        while (kuh1 != "y");

        rental stock = new rental();
        System.out.print("Movie Stock   => ");
        stock.stok = in2.nextInt();


        rental operation = new rental();
        operation.Prefix();

        title.Title();
        actor.Actor();
        director.Director();
        publisher.Publisher();
        kel.Categori();
        stock.Stock();

    }
}