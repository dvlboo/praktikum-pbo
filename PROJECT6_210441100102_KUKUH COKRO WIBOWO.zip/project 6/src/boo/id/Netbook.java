package boo.id;

import static java.lang.Thread.sleep;

public class Netbook extends Computer implements Mouse, Keyboard, Printer {
    void hidupkan_os() throws InterruptedException {
        System.out.println("\n\n------------------------------------");
        System.out.println("Ubuntu LTS 22.04 on dvlBoo Netbook's");
        System.out.println("------------------------------------\n");
        sleep(500);
        System.out.println("Turn On Ubuntu");
        System.out.println("System Operation Loading...");
        sleep(2000);
        System.out.println("=> ON <=");
        sleep(500);
    }

    void matikan_os() throws InterruptedException {
        System.out.println("\nTurn Off Ubuntu");
        System.out.println("Close all your Ubuntu Tab");
        sleep(500);
        System.out.println("Preparation to Shutdown");
        sleep(500);
        System.out.println("System Operation Loading...");
        sleep(2000);
        System.out.println("=> OFF <=");
        sleep(500);
    }

    public void klik_kanan() throws InterruptedException {
        System.out.println("\nChecking Right Click");
        sleep(500);
        System.out.println("R Click...");
        sleep(2000);
        System.out.println("=> Active <=");
        sleep(500);
    }

    public void klik_kiri() throws InterruptedException {
        System.out.println("\nChecking Left Click");
        sleep(500);
        System.out.println("L Click...");
        sleep(2000);
        System.out.println("=> Active <=");
        sleep(500);
    }

    public void tekan_enter() throws InterruptedException {
        System.out.println("\nChecking Button Enter");
        sleep(500);
        System.out.println("Enter...");
        sleep(2000);
        System.out.println("=> Active <=");
        sleep(500);
    }

    public void cetak_data() throws InterruptedException {
        System.out.println("\nChecking Print Data Operation");
        sleep(500);
        System.out.println("Print Data...");
        sleep(2000);
        System.out.println("=> Active <=");
        sleep(500);
    }
}