package boo.id;

public interface Mouse {
    public void klik_kanan() throws InterruptedException;

    public void klik_kiri() throws InterruptedException;
}