package boo.id;

final class Main {
    private static void cetak(Computer[] OBJ) throws InterruptedException {
        OBJ[0] = new PC();
        OBJ[1] = new Laptop();
        OBJ[2] = new Netbook();

        System.out.println("\nNAMA  : Kukuh Cokro Wibowo");
        System.out.println("NIM   : 210441100102");
        System.out.println("KELAS : PBO A\n");
        System.out.println("=== SHOW THE OS ===\n");

        for (int i = 0; i < OBJ.length; i++) {
            OBJ[i].hidupkan_os();
            OBJ[i].klik_kanan();
            OBJ[i].klik_kiri();
            OBJ[i].tekan_enter();
            OBJ[i].cetak_data();
            OBJ[i].matikan_os();
        }
    }

    public static void main(String[] args) throws InterruptedException {
        Computer[] computers = new Computer[3];
        cetak(computers);
    }
}