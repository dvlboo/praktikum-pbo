package boo.id;

public interface Printer {
    public void cetak_data() throws InterruptedException;
}