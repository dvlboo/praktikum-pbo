package boo.id;

import static java.lang.Thread.sleep;

public class Laptop extends Computer implements Mouse, Keyboard, Printer {
    void hidupkan_os() throws InterruptedException {
        System.out.println("\n\n-----------------------------");
        System.out.println("Linux Mint on dvlBoo Laptop's");
        System.out.println("-----------------------------\n");
        sleep(500);
        System.out.println("Turn On Linux");
        System.out.println("System Operation Loading...");
        sleep(1800);
        System.out.println("=> ON <=");
        sleep(500);
    }

    void matikan_os() throws InterruptedException {
        System.out.println("\nTurn Off Linux");
        System.out.println("Close all your Linux Tab");
        sleep(500);
        System.out.println("Preparation to Shutdown");
        sleep(500);
        System.out.println("System Operation Loading...");
        sleep(1800);
        System.out.println("=> OFF <=");
        sleep(500);
    }

    public void klik_kanan() throws InterruptedException {
        System.out.println("\nChecking Right Click");
        sleep(500);
        System.out.println("R Click...");
        sleep(1800);
        System.out.println("=> Active <=");
        sleep(500);
    }

    public void klik_kiri() throws InterruptedException {
        System.out.println("\nChecking Left Click");
        sleep(500);
        System.out.println("L Click...");
        sleep(1800);
        System.out.println("=> Active <=");
        sleep(500);
    }

    public void tekan_enter() throws InterruptedException {
        System.out.println("\nChecking Button Enter");
        sleep(500);
        System.out.println("Enter...");
        sleep(1800);
        System.out.println("=> Active <=");
        sleep(500);
    }

    public void cetak_data() throws InterruptedException {
        System.out.println("\nChecking Print Data Operation");
        sleep(500);
        System.out.println("Print Data...");
        sleep(1800);
        System.out.println("=> Active <=");
        sleep(500);
    }
}