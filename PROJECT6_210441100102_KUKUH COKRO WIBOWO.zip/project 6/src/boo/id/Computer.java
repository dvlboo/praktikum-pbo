package boo.id;

public abstract class Computer implements Mouse, Keyboard, Printer {
    abstract void hidupkan_os() throws InterruptedException;

    abstract void matikan_os() throws InterruptedException;
}