package boo.id;

public interface Keyboard {
    public void tekan_enter() throws InterruptedException;
}