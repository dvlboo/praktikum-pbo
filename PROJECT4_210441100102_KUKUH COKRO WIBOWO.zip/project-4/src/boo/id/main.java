package boo.id;

public class main {
    private static void printAll(bilangan[] OB, double a, double b) {
        OB[0] = new penjumlahan();
        OB[1] = new pengurangan();
        OB[2] = new perkalian();
        OB[3] = new pembagian();

        for (int kuh = 0; kuh < OB.length; kuh++) {
            OB[kuh].setA(a);
            OB[kuh].setB(b);
            OB[kuh].setC();
            OB[kuh].runningProgram();
        }
    }

    public static void main(String[] args) {
        bilangan[] array = new bilangan[4];
        printAll(array, 10.5, 0.5);
        System.out.println("==== PROGRAM SELESAI ====");
    }
}
