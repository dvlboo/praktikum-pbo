package boo.id;

public class perkalian extends bilangan{
    @Override
    protected void setC() {
        this.c = this.a * this.b;
    }

    protected void runningProgram() {
        System.out.println("Operasi Perkalian : ");
        System.out.println("Bilangan A     = " + this.getA());
        System.out.println("Bilangan B     = " + this.getB());
        System.out.println("Bilangan A * B = " + this.getC() + "\n");
    }
}
