package boo.id;

public class bilangan {
    protected double a, b, c;

    protected void setA(double bil_A) {
        this.a = bil_A;
    }

    protected double getA() {
        return this.a;
    }

    protected void setB(double bil_B) {
        this.b = bil_B;
    }

    protected double getB() {
        return this.b;
    }

    protected void setC() {
    }

    protected double getC() {
        return this.c;
    }

    protected void runningProgram() {
        System.out.println("=== HASIL RUN PROGRAM ===\n");
    }
}
